<?php $__env->startSection('content'); ?>
<div class="login">
    <div class="left">
        <?php echo $__env->yieldContent('content-login'); ?>
    </div>
    <div class="rigth">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo $__env->yieldContent('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/layouts/login-layout.blade.php ENDPATH**/ ?>