<?php $__env->startSection('content'); ?>
<div class="main-container">

    <div class="navbar-left">
        <div class="header-navbar">
            Horario Docente
        </div>
        <div class="user-container">
            <div class="avatar"></div>

            <?php if(auth()->guard()->check()): ?>
            <div class="name-user"><?php echo e(Auth::user()->nombres); ?> <?php echo e(Auth::user()->apellidos); ?></div>

            <?php if(Auth::user()->tipoUsuario()->count() != 0): ?>
            <div class="role-user"><?php echo e(Auth::user()->tipoUsuario()->first()->nombre); ?></div>
            <?php else: ?>
            <div class="role-user">Sin rol</div>
            <?php endif; ?>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?>
            <div class="role-user">Usuario</div>
            <?php endif; ?>
        </div>
        <div class="menu">
            <div class="item"><a class="<?php echo e(Request::is('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Inicio</a></div>

            <?php if(Auth::user()->hasAnyRole(['Docente'])): ?>
            <div class="item"><a class="<?php echo e((Request::is('disponibilidad*') || Request::is('usuarios/periodos*')) ? 'active' : ''); ?>" href="<?php echo e(route('disponibilidad.index')); ?>">Disponibilidad</a></div>

            <div class="item">
                <a class="<?php echo e(Request::is('usuarios/asignaturas*') ? 'active' : ''); ?>" href="<?php echo e(route('usuarios.asignaturas', Auth::user())); ?>">Mis asignaturas</a></div>
            <?php endif; ?>

            <?php if(Auth::user()->hasAnyRole(['Administrador'])): ?>
            <div class="item"><a class="<?php echo e(Request::is('usuarios*') ? 'active' : ''); ?>" href="<?php echo e(route('usuarios.index')); ?>">Usuarios</a></div>
            <?php endif; ?>

            <?php if(Auth::user()->hasAnyRole(['Administrador', 'Director'])): ?>
            <div class="item"><a href="#">Facultades</a></div>

            <div class="item"><a class="<?php echo e(Request::is('programas*') ? 'active' : ''); ?>" href="<?php echo e(route('programas.index')); ?>">Programas</a></div>

            <div class="item"><a href="#">Horarios</a></div>
            <div class="item"><a  class="<?php echo e(Request::is('grupos*') ? 'active' : ''); ?>"  href="<?php echo e(route('grupos.index')); ?>">Grupos</a></div>

            <div class="item"><a class="<?php echo e(Request::is('asignaturas*') ? 'active' : ''); ?>" href="<?php echo e(route('asignaturas.index')); ?>">Asignaturas</a></div>
            <?php endif; ?>

            <?php if(Auth::user()->hasAnyRole(['Coordinador'])): ?>
            <div class="item"><a href="#">Salones</a></div>
            <?php endif; ?>
        </div>
        <div class="logout">
            <span class="top"></span>
            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i>
                <?php echo e(__('Salir')); ?>

            </a>
            <span class="bottom"></span>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
    <div class="content">
        <div class="navbar-horizontal">

            <?php if(Auth::user()->hasAnyRole(['Administrador'])): ?>
            <div>
                <div class="item" data-toggle="dropdown"><i class="fas fa-cog"></i></div>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Opciones de administrador</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#"><i class="far fa-calendar"></i> Periodos académicos</a>
                    <a class="dropdown-item" href="#"><i class="fas fa-university"></i> Sedes</a>
                </div>
            </div>
            <?php endif; ?>

            <div class="item"><i class="fas fa-bell"></i><span class="badge badge-notify">9</span></div>

            <div>
                <div class="item" data-toggle="dropdown"><i class="fas fa-user-circle"></i></div>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#"><?php echo e(Auth::user()->nombres); ?> <?php echo e(Auth::user()->apellidos); ?></a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('informacion.index')); ?>"><i class="far fa-address-card"></i> Mi información</a>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                        <i class="fas fa-sign-out-alt"></i>
                        <?php echo e(__('Salir')); ?></a>
                </div>
            </div>
        </div>
        <div class="contenido">
            <?php echo $__env->yieldContent('contenido'); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo $__env->yieldContent('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>