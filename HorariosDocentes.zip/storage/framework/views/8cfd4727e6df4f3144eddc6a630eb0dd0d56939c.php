<?php $__env->startSection('contenido'); ?>
<div class="title-contenido">
    <div class="back">
        <a class="btn btn-link" href="<?php echo e(route('asignaturas.index')); ?>">
            <i class="fas fa-arrow-left"></i>
            Volver
        </a>
    </div>
    <h2>Registrar nueva</h2>
    <h1>Asignatura</h1>
</div>
<div class="main-contenido">
    <?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('asignaturas.store')); ?>">
        <?php echo csrf_field(); ?>
        <span style="display: block; margin-bottom: 1rem;">Todos los campos son obligatorios.</span>
        <div class="group-inputs-2">
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" name="nombre" autocomplete="off" placeholder="Ingrese el nombre">
            </div>
            <div class="group-inputs-2">
                <div class="form-group">
                    <label for="codigo">C&oacute;digo</label>
                    <input type="text" class="form-control" name="codigo" autocomplete="off" placeholder="Ingrese el c&oacute;digo">
                </div>
                <div class="form-group">
                    <label for="creditos">Cr&eacute;ditos</label>
                    <input type="number" class="form-control" autocomplete="off" name="creditos" placeholder="Ingrese los cr&eacute;ditos">
                </div>
            </div>
        </div>
        <div class="form-group buttons">
            <button type="submit" class="btn btn-success">
                Registrar
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/asignaturas/create.blade.php ENDPATH**/ ?>