<?php $__env->startSection('contenido'); ?>
<div class="title-contenido">
    <?php if(Auth::user()->hasRole('Docente')): ?>
    <h2>Mi</h2>
    <h1>Disponibilidad</h1>
    <?php else: ?>
    <?php if(Auth::user()->hasRole('Administrador')): ?>
    <div class="back">
        <a class="btn btn-link" href="<?php echo e(route('usuarios.show', $usuario)); ?>">
            <i class="fas fa-arrow-left"></i>
            Volver
        </a>
    </div>
    <?php endif; ?>
    <h2>Usuario</h2>
    <h1><?php echo e($usuario->nombres); ?> <?php echo e($usuario->apellidos); ?></h1>
    <h3>Disponibilidad</h3>
    <?php endif; ?>
</div>
<div class="main-contenido">
    <div class="container-list">
        <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        <div class="filtros">
            <?php if(Auth::user()->hasRole('Docente')): ?>
            <form method="POST" action="<?php echo e(route('disponibilidad.index')); ?>">
                <?php else: ?>
                <form method="POST" action="<?php echo e(route('usuarios.disponibilidad', $usuario)); ?>">
                    <?php endif; ?>
                    <?php echo method_field('GET'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="title-filtro"><?php echo e(__('Filtros')); ?></div>
                    <div class="group-inputs-2">
                        <div class="form-group" style="margin-right: 2rem;">
                            <label for="año">Año</label>
                            <input type="number" class="form-control" name="año" placeholder="Buscar por año" value="<?php echo e(old('año')); ?>">
                        </div>
                        <div class="form-group checks">
                            <label>Periodo</label>
                            <div class="group-inputs-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="periodo" id="1" value="1" <?php if(old('periodo')==1): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="1">
                                        Periodo 1
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="periodo" id="2" value="2" <?php if(old('periodo')==2): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="2">
                                        Periodo 2
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="periodo" id="3" value="3" <?php if(old('periodo')==3): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="3">
                                        Todos
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group buttons">
                        <span></span>
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Aplicar')); ?>

                        </button>
                    </div>
                </form>
        </div>
        <?php if(Auth::user()->hasRole('Docente')): ?>
        <div class="action">
            <a href="<?php echo e(route('disponibilidad.create')); ?>" title="Nueva disponibilidad">
                <span class="icon text-success">
                    <i class="fas fa-plus-circle"></i>
                </span>
                <span class="text-dark">Registrar una disponibilidad</span>
            </a>
        </div>
        <?php endif; ?>
        <?php if($periodos->count() != 0): ?>
        <div class="list-dispo">
            <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="block block-yellow">
                <div class="block-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div class="block-text">
                    <div>
                        <h3><?php echo e($periodo->año); ?></h3>
                        <h2>Periodo <?php echo e($periodo->periodo); ?></h2>
                        <?php if(Auth::user()->hasRole('Administrador')): ?>
                        <a class="btn-link text-white" href="<?php echo e(route('periodo.disponibilidad', [$usuario, $periodo])); ?>">
                            <?php echo e(__('Ver')); ?>

                        </a>
                        <?php else: ?>
                        <a class="btn-link text-white" href="<?php echo e(route('periodo.disponibilidad', [Auth::user(), $periodo])); ?>">
                            <?php echo e(__('Ver')); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($periodos->appends(Request::except('page'))->links()); ?>

        <?php else: ?>
        No encontramos registrada ninguna disponibilidad
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/usuarios/disponibilidad.blade.php ENDPATH**/ ?>