<?php $__env->startSection('contenido'); ?>
<div class="title-contenido">
    <div class="back">
        <a class="btn btn-link" href="<?php echo e(route('asignaturas.index')); ?>">
            <i class="fas fa-arrow-left"></i>
            Volver
        </a>
    </div>
    <h2>Asignatura</h2>
    <h1><?php echo e($asignatura->nombre); ?></h1>
</div>
<div class="main-contenido">
    <?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('asignaturas.update', $asignatura)); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="group-inputs-2">
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" value="<?php echo e($asignatura->nombre); ?>" disabled="true">
            </div>
            <div class="group-inputs-2">
                <div class="form-group">
                    <label for="codigo">C&oacute;digo</label>
                    <input type="text" class="form-control" id="codigo" name="codigo" placeholder="C&oacute;digo" value="<?php echo e($asignatura->codigo); ?>" disabled="true">
                </div>
                <div class="form-group">
                    <label for="creditos">Cr&eacute;ditos</label>
                    <input type="number" class="form-control" id="creditos" name="creditos" placeholder="Cr&eacute;ditos" value="<?php echo e($asignatura->creditos); ?>" disabled="true">
                </div>
            </div>
        </div>
        <div class="form-group buttons">
            <button id="editar" type="button" class="btn btn-primary">
                <?php echo e(__('Editar')); ?>

            </button>
            <button id="cancelar" type="button" class="btn btn-danger hidden">
                <?php echo e(__('Cancelar')); ?>

            </button>
            <button id="cambios" type="submit" class="btn btn-success hidden">
                <?php echo e(__('Guardar cambios')); ?>

            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/informacion.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/asignaturas/edit.blade.php ENDPATH**/ ?>