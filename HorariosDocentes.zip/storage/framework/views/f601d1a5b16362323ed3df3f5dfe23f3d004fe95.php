<?php $__env->startSection('content'); ?>
<div class="unauthorized" style="margin-top: 2rem;">
    <img src="img/notfound.png">
    <h1 style="font-size: 3rem">404</h1>
    <h1>Recurso no encontrado.</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/errors/404.blade.php ENDPATH**/ ?>