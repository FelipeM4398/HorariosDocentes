<?php $__env->startSection('contenido'); ?>
<div class="title-contenido">
    <h2>Programas</h2>
    <h1>Académicos</h1>
</div>
<div class="main-contenido">
    <?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
    <div class="filtros">
        <form method="POST" action="<?php echo e(route('programas.index')); ?>">
            <?php echo method_field('GET'); ?>
            <?php echo csrf_field(); ?>
            <div class="title-filtro"><?php echo e(__('Filtros')); ?></div>
            <div class="group-inputs-3">
                <div class="form-group">
                    <label for="nombre">Nombre</label>
                    <input id="nombre" type="text" class="form-control" name="nombre" placeholder="Buscar por nombre" value="<?php echo e(old('nombre')); ?>" autocomplete="off">
                </div>
                <div class="form-goup">
                    <label for="modalidad">Modalidad</label>
                    <select name="modalidad" class="form-control">
                        <option value="">Buscar por modalidad</option>
                        <?php $__currentLoopData = $modalidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($modalidad->id); ?>" <?php if(old('modalidad')==$modalidad->id): ?> selected <?php endif; ?>><?php echo e($modalidad->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tipo">Tipo de programa</label>
                    <select name="tipo" class="form-control">
                        <option value="">Buscar por tipo</option>
                        <?php $__currentLoopData = $tipoProgramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoPrograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipoPrograma->id); ?>" <?php if(old('tipo')==$tipoPrograma->id): ?> selected <?php endif; ?>><?php echo e($tipoPrograma->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="buttons">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('Aplicar')); ?>

                </button>
            </div>
        </form>
    </div>
    <div class="table-responsive">
        <div class="action">
            <a href="<?php echo e(route('programas.create')); ?>" title="Nuevo programa">
                <span class="icon text-success">
                    <i class="fas fa-plus-circle"></i>
                </span>
                <span class="text-dark">Registrar nuevo programa</span>
            </a>
        </div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Modalidad</th>
                    <th scope="col">Tipo de programa</th>
                    <th scope="col" style="text-align: center;">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($programa->nombre); ?></td>
                    <td scope="row"><?php echo e($programa->modalidad->nombre); ?></td>
                    <td scope="row"><?php echo e($programa->tipoPrograma->nombre); ?></td>

                    <td style="text-align: center;">
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('programas.edit', $programa)); ?>">
                            <i class="fas fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($programas->appends(Request::except('_token', '_method'))->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/programas/index.blade.php ENDPATH**/ ?>