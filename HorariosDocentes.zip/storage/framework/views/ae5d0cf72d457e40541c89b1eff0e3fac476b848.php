<?php $__env->startSection('content-login'); ?>
<div class="form-left-container">
    <h2 class="form-subtitle">Bienvenido a</h2>
    <h1 class="form-title">Horario Docente</h1>
    <div class="buttons">
        <a href="#" class="btn btn-warning text-dark btn-sm">
            <i class="fas fa-sign-in-alt" style="margin-right: .2rem;"></i>Entrar como invitado
        </a>
    </div>
    <form class="form-left" method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="identificacion"><?php echo e(__('Indentificación')); ?></label>
            <input id="identificacion" type="number" class="form-control <?php $__errorArgs = ['identificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ingrese su número de identificación" name="identificacion" value="<?php echo e(old('identificacion')); ?>" required>
            <?php $__errorArgs = ['identificacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="password"><?php echo e(__('Contraseña')); ?></label>
            <input id="password" type="password" placeholder="Ingrese su contraseña" class="form-control" name="password" required autocomplete="current-password">
        </div>
        <div class="form-group form-buttons">
            <div class="buttons-login">
                <?php if(Route::has('password.request')): ?>
                <a class="btn-link" href="<?php echo e(route('password.request')); ?>">
                    <?php echo e(__('¿Olvidó su contraseña?')); ?>

                </a>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-sign-in-alt"></i>
                    <?php echo e(__('Entrar')); ?>

                </button>
            </div>
            <?php if(Route::has('register')): ?>
            <a class="btn btn-link registrarse" href="<?php echo e(route('register')); ?>"><?php echo e(__('¿No tienes una cuenta?')); ?></a>
            <?php endif; ?>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/auth/login.blade.php ENDPATH**/ ?>