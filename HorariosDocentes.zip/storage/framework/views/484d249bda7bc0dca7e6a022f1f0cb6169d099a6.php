<?php $__env->startSection('contenido'); ?>
<div class="title-contenido">
    <h2>Ver</h2>
    <h1>Usuarios</h1>
</div>
<div class="main-contenido">
    <div class="filtros">
        <form method="POST" action="<?php echo e(route('usuarios.index')); ?>">
            <?php echo method_field('GET'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="title-filtro"><?php echo e(__('Filtros')); ?></div>
                <div class="group-inputs-3">
                    <div>
                        <label for="identificacion">Identificación</label>
                        <input id="identificacion" type="number" class="form-control" name="identificacion" placeholder="Buscar por identificación" value="<?php echo e(old('identificacion')); ?>">
                    </div>
                    <div>
                        <label for="nombre">Nombre</label>
                        <input id="nombre" type="text" class="form-control" name="nombre" placeholder="Buscar por nombre" value="<?php echo e(old('nombre')); ?>" autocomplete="off">
                    </div>
                    <div>
                        <label for="nombre">Apellido</label>
                        <input id="apellido" type="text" class="form-control" name="apellido" placeholder="Buscar por apellido" value="<?php echo e(old('apellido')); ?>" autocomplete="off">
                    </div>
                </div>
            </div>
            <label style="padding-left: 15px;">Buscar por rol:</label>
            <div class="form-group roles">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="rol" id="decano" value="2" <?php if(old('rol')==2): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="decano">
                        Decano
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="rol" id="director" value="3" <?php if(old('rol')==3): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="director">
                        Director
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="rol" id="docente" value="4" <?php if(old('rol')==4): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="docente">
                        Docente
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="rol" id="coordinador" value="5" <?php if(old('rol')==5): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="coordinador">
                        Coordinador
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="rol" id="sin" value="6" <?php if(old('rol')==6): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="sin">
                        Sin asignar
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="rol" id="todos" value="" <?php if(old('rol')=='' ): ?> checked <?php endif; ?>>
                    <label class="form-check-label" for="todos">
                        Todos
                    </label>
                </div>
            </div>
            <div class="buttons">
                <span></span>
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('Aplicar')); ?>

                </button>
            </div>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">Identificación</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Correo</th>
                    <th scope="col">Rol</th>
                    <th scope="col">Ver más</th>
                </tr>
            </thead>
            <tbody>
                <?php if($usuarios->count() == 0): ?>
                <tr>
                    <td colspan="4">No se encuentraron usuarios</td>
                </tr>
                <?php else: ?>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($usuario->identificacion); ?></th>
                    <td><?php echo e($usuario->nombres); ?> <?php echo e($usuario->apellidos); ?></td>
                    <td><?php echo e($usuario->email); ?> </td>
                    <td>
                        <?php if($usuario->tipoUsuario()->count() == 0): ?>
                        Sin asignar
                        <?php else: ?>
                        <?php echo e($usuario->tipoUsuario()->first()->nombre); ?>

                        <?php endif; ?>
                    </td>
                    <td style="text-align: center;"><a class="btn btn-primary btn-sm" href="<?php echo e(route('usuarios.show', $usuario)); ?>"><i class="fas fa-eye"></i></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($usuarios->appends(Request::except('page'))->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/usuarios/usuarios.blade.php ENDPATH**/ ?>