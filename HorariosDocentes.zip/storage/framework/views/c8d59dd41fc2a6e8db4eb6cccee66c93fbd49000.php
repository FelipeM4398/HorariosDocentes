<?php $__env->startSection('contenido'); ?>
<div class="title-contenido">
    <div class="back">
        <a class="btn btn-link" href="<?php echo e(route('programas.index')); ?>">
            <i class="fas fa-arrow-left"></i>
            Volver
        </a>
    </div>
    <h2>Registrar nuevo</h2>
    <h1>Programa académico</h1>
</div>
<div class="main-contenido">
    <?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('programas.store')); ?>">
        <?php echo csrf_field(); ?>
        <span style="display: block; margin-bottom: 1rem;">Los campos marcados con (*) son obligatorios.</span>
        <div class="group-inputs-2">
            <div class="form-group">
                <label for="nombre">*Nombre</label>
                <input type="text" class="form-control" name="nombre" placeholder="Ingrese el nombre" required>
            </div>
            <div class="group-inputs-2">
                <div class="form-group">
                    <label for="id_tipo_programa">*Tipo de programa</label>
                    <select class="form-control" name="id_tipo_programa" required>
                        <option value="" selected>Seleccione un tipo de programa</option>
                        <?php $__currentLoopData = $tipoProgramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoPrograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipoPrograma->id); ?>">
                            <?php echo e($tipoPrograma->nombre); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="duracion">*Duraci&oacute;n</label>
                    <input type="number" step="1" class="form-control" name="duracion" placeholder="Ingrese la duraci&oacute;n" required>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="descripcion">Descripci&oacute;n</label>
            <textarea style="white-space: unset;" rows="4" class="form-control" name="descripcion" placeholder="Ingrese una descripci&oacute;n">
            </textarea>
        </div>
        <div class="group-inputs-3">
            <div class="form-group">
                <label for="id_facultad">*Facultad</label>
                <select class="form-control" name="id_facultad" required>
                    <option value="" selected>Seleccione una facultad</option>
                    <?php $__currentLoopData = $facultades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facultad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($facultad->id); ?>">
                        <?php echo e($facultad->nombre); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_director">Director</label>
                <select class="form-control" name="id_director">
                    <option value="" selected>Seleccione un director</option>
                    <?php $__currentLoopData = $directores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($director->id); ?>">
                        <?php echo e($director->nombres); ?> <?php echo e($director->apellidos); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_modalidad">*Modalidad</label>
                <select class="form-control" id="modalidad" name="id_modalidad" required>
                    <option value="" selected>Seleccione una modalidad</option>
                    <?php $__currentLoopData = $modalidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($modalidad->id); ?>">
                        <?php echo e($modalidad->nombre); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group buttons">
            <button type="submit" class="btn btn-success">
                <?php echo e(__('Registrar')); ?>

            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HorariosDocentes\resources\views/programas/create.blade.php ENDPATH**/ ?>