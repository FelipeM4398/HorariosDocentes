@extends('layouts.app')

@section('content')
<div class="unauthorized" style="margin-top: 2rem;">
    <img src="img/notfound.png">
    <h1 style="font-size: 3rem">404</h1>
    <h1>Recurso no encontrado.</h1>
</div>
@endsection