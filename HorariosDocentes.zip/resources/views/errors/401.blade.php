@extends('layouts.dashboard')

@section('contenido')
<div class="unauthorized">
    <img src="img/unauthorized.png">
    <h1>No tienes permisos para realizar esta acción.</h1>
</div>
@endsection