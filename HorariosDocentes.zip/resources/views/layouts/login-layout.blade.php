@extends('layouts.app')

@section('content')
<div class="login">
    <div class="left">
        @yield('content-login')
    </div>
    <div class="rigth">
    </div>
</div>
@endsection

@section('scripts')
@yield('scripts')
@endsection